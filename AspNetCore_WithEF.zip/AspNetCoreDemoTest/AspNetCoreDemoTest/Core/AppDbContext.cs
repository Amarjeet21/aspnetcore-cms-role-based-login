﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using AspNetCoreDemoTest.Core.Domain;
using AspNetCoreDemoTest.Core.EntityConfiguration;
using Microsoft.EntityFrameworkCore;

namespace AspNetCoreDemoTest.Core
{
    public class AppDbContext : IdentityDbContext<ApplicationUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public virtual DbSet<UserDetails> UserDetails { get; set; }
        public virtual DbSet<Page> Page { get; set; }

        public virtual DbSet<Contact> Contact { get; set; } 
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //Setup Configuration file here 
            modelBuilder.ApplyConfiguration(new UserDetailsConfiguration());
        }
    }




    //public class AppDbContext : DbContext
    //{
    //    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    //    {

    //    }
    //    public virtual DbSet<UserDetails> UserDetails { get; set; }
    //    protected override void OnModelCreating(ModelBuilder modelBuilder)
    //    {
    //        base.OnModelCreating(modelBuilder);

    //        //Setup Configuration file here 
    //        modelBuilder.ApplyConfiguration(new UserDetailsConfiguration());
    //    }
    //}
}

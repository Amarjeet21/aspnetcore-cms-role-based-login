﻿using System;

namespace AspNetCoreDemoTest.Core.Domain
{
    public class UserDetails
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }       
        public string Phone { get; set; }
        public string Address { get; set; }
        public bool IsActive { get; set; }
        public bool IsDelete { get; set; }
        public DateTimeOffset CreatedOn { get; set; }
        public string Createdby { get; set; }        
    }
}

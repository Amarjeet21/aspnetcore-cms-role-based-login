﻿using AspNetCoreDemoTest.Core.Interface;
using AspNetCoreDemoTest.Core.Repositories;
using Microsoft.Extensions.DependencyInjection;

namespace AspNetCoreDemoTest.Core.Extension
{
    public static class DatabaseDependencyInjectionExtension
    {
        public static IServiceCollection AddDatabaseDependency(this IServiceCollection services)
        {
            services.AddTransient<IUserDetailsRepository, UserDetailsRepository>();
            services.AddTransient<IPageRepository, PageRepository>();
            services.AddTransient<IContactRepository, ContactRepositry>();
            services.AddTransient<IUnitOfWork, UnitOfWork>();

            return services;
        }
    }
}

﻿using AspNetCoreDemoTest.Core.Interface;
using System;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Core
{
    public interface IUnitOfWork : IDisposable
    {
        IUserDetailsRepository UserDetails { get; set; }
        IPageRepository Page { get; set; }

        IContactRepository Contact { get; set; } 

        int SaveChanges();
        Task<int> SaveChangesAsync();
    }
}

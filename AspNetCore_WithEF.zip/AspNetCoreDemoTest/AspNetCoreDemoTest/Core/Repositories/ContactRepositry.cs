﻿using AspNetCoreDemoTest.Core.Domain;
using AspNetCoreDemoTest.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Core.Repositories
{
    public class ContactRepositry : Repository<Contact>, IContactRepository
    {
        public ContactRepositry(AppDbContext context) : base(context) 
        {

        }
    }
}

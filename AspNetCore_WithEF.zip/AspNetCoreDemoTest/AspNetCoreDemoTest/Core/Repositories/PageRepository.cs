﻿using AspNetCoreDemoTest.Core.Domain;
using AspNetCoreDemoTest.Core.Interface;
using AspNetCoreDemoTest.Dtos;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Core.Repositories
{
    public class PageRepository : Repository<Page>, IPageRepository
    {
        public PageRepository(AppDbContext context) : base(context) 
        {
            
        }
        public List<PageDto> GetAllPage(string searchQuery = "") 
        {
            var pages = _context.Page.AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchQuery))
                pages = pages.Where(e => e.PageTitle.Contains(searchQuery) || e.Slug.Contains(searchQuery));

            var query = from p in pages
                        select (new PageDto
                        {
                            Id = p.Id,
                            PageTitle = p.PageTitle,
                            Slug = p.Slug,                            
                            IsActive = p.IsActive,
                            IsDelete = p.IsDelete
                        });

            var result = query.ToList();

            return result;
        }

        public async Task<List<PageDto>> GetAllPagesAsync(string searchQuery = "") 
        {
            var pages = _context.Page.AsQueryable();
           
            if (!string.IsNullOrWhiteSpace(searchQuery))
                pages = pages.Where(e => e.PageTitle.Contains(searchQuery) || e.Slug.Contains(searchQuery));

            var query = from p in pages
                        select (new PageDto
                        {
                            Id = p.Id,
                            PageTitle = p.PageTitle,
                            Slug = p.Slug,
                            IsActive = p.IsActive,
                            IsDelete = p.IsDelete
                        });

            var result = await query.ToListAsync();
            return result;
        }

        public  List<PageDto> GetPageDetailsBySlug(string slug="") 
        {
            var pages = _context.Page.AsQueryable();

            if (!string.IsNullOrWhiteSpace(slug))
                pages = pages.Where(e => e.Slug.Contains(slug) || e.Slug.Contains(slug));

            var query = from p in pages where p.Slug.Equals(slug)
                        select (new PageDto
                        {
                            Id = p.Id,
                            PageTitle = p.PageTitle,
                            Slug = p.Slug,
                            Page_Content =  p.Page_Content,
                            Master_Page =  p.Master_Page,
                            IsActive = p.IsActive,
                            IsDelete = p.IsDelete
                        });

            var result = query.ToList();

            return result;
        }


        public  Page GetBySlug(string slug)
        {
            var data = _context.Page
               .Where(e => e.Slug == slug && e.IsActive ==  false);
            return data.FirstOrDefault();
        }

        //public PageDto GetByTopicUrl(string slug)
        //{           
        //    var result  = _context.Page.Where(e => e.Slug == slug).FirstOrDefault();
        //    return PageDto; 
        //}
    }
}

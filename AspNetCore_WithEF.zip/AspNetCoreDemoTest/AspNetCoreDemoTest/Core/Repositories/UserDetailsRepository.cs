﻿using AspNetCoreDemoTest.Core;
using AspNetCoreDemoTest.Core.Domain;
using AspNetCoreDemoTest.Core.Interface;

namespace AspNetCoreDemoTest.Core.Repositories
{
    public class UserDetailsRepository : Repository<UserDetails>, IUserDetailsRepository
    {
        public UserDetailsRepository(AppDbContext context) : base(context)
        {

        }
    }
}

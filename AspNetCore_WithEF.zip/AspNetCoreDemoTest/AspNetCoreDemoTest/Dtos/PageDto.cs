﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Dtos
{
    public class PageDto
    {
        public int Id { get; set; }
        public String Slug { get; set; }
        public String PageTitle { get; set; }
        public String Page_Content { get; set; }
        public String Description { get; set; }
        public String Keywords { get; set; }
        public String Master_Page { get; set; }
        public String Meta_Tag { get; set; }
        public bool IsActive { get; set; }
        public bool IsDelete { get; set; }
    }
}

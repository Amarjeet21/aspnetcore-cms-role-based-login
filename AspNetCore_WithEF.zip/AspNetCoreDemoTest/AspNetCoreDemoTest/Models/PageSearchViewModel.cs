﻿using AspNetCoreDemoTest.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Models
{
    public class PageSearchViewModel
    {
        public List<PageDto> Pages { get; set; } 
        public int Page { get; set; }
        public int Count { get; set; }
        public int TotalRecord { get; set; }
        public string Q { get; set; }
        public string PageStatus { get; set; }

        

    }
}

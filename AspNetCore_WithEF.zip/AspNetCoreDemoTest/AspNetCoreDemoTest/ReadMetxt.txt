﻿
Install EntityFrameworkCore 
Install EntityFrameworkCore  sql server
Install EntityFrameworkCore Tools


PM>Update-Database

add new table 

PM> add-migration [anyname without space']
PM> update-database


Note : Only Insert Role Name in table same like Utility folder >> UserRoles

Example : 


public class UserRoles
{
    public const string Admin = "Admin";
    public const string User = "User";
}